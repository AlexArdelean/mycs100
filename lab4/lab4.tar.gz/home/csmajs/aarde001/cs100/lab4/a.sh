echo "$1"
