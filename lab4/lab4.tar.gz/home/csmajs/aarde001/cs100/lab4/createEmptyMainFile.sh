cat main.cc
cat alex_0951.txt > main.cc 
echo "int main(int argc, const char** argv)" >> alex_0951.txt
echo "{}" >> alex_0951.txt
