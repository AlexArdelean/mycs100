echo $1 $2
