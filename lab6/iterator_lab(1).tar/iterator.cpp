


classIterator{
protected:
Base*self_ptr;
Base*current_ptr;
public:
Iterator(Base*ptr){this->self_ptr=ptr;}
/*Setsuptheiteratortostartatthebeginningoftraversal*/
virtualvoidfirst()=0;
/*Moveontothenextelement*/
virtualvoidnext()=0;
/*Returnsifyouhavefinishediteratingthroughallelements*/
virtualboolis_done()=0;
/*Returntheelementtheiteratoriscurrentlyat*/
virtualBase*current()=0;
};



//The OperatorIterator will be used to iterate over composite nodes with two children. 
//This means it�s first will initialize to the left child, 
//and its next will cycle from left child (which is where it is set
//to start), to right child, then to NULL.
classOperatorIterator:publicIterator{
public:
OperatorIterator(Base*ptr);
voidfirst();
voidnext();
boolis_done();
Base*current();
};


//The UnaryIterator will be used to iterate over composite nodes 
//with one child (only Sqr in our case). 
//This means it�s first will initialize to the only child 
//(which has been redeclared in the composite class as the left child, 
//with Unary having no right child to make for an easier
interface), and next will cycle from child (which is where it is set to start) to NU
classUnaryIterator:publicIterator{
public:
UnaryIterator(Base*ptr);
voidfirst();
voidnext();
boolis_done();
Base*current();
};


//The NullIterator is used to iterate over leaf nodes. 
//Since leaf nodes have no children, the
//NullIterator�s is_done() will always return true and it�s current() 
//will always return NULL. It�s first()
//and next() functions don�t need to do anything.

classNullIterator:publicIterator{
public:
NullIterator(Base*ptr);
voidfirst();
voidnext();
boolis_done();
Base*current();
};

//The PreOrderIterator has an additional stack data member, 
//which we will use to keep tack of the collection iterators that
//we need to traverse. The rest of the functions will be written as
//follows

classPreOrderIterator:publicIterator{
protected:
stack<Iterator*>iterators;
public:
PreOrderIterator(Base*ptr);
voidfirst();
voidnext();
boolis_done();
Base*current();
};




voidPreOrderIterator::first(){
//Emptythestack(justincasewehadsomethingleftoverfrom
//anotherrun)
//CreateaniteratorfortheBase*thatwebuilttheiteratorfor
//Initializethatiteratorandpushitontothestack
}
voidPreOrderIterator::next(){
//Createaniteratorfortheitemonthetopofthestack
//Initializetheiteratorandpushitontothestack
//Aslongasthetopiteratoronthestackisdone,popitoffthe
//stackandthenadvancewhateveriteratorisnowontopofthestack
}
boolPreOrderIterator::is_done(){
//Returntrueiftherearenomoreelementsonthestacktoiterate
}
Base*PreOrderIterator::current(){
//Returnthecurrentforthetopiteratorinthestack
}

